# SO-ARM101 simulation control handoff

Start with [simulation/README.md](simulation/README.md), then [CONTROL_HANDOFF.md](CONTROL_HANDOFF.md). This is the control-only package; no vision weights, runtime environment, credentials or recordings of a new trial are included.

Extract this folder, create a virtual environment, install simulation/requirements.txt and follow the materialization and gated environment-check commands. Skip the guide's Git clone commands when using this ZIP.

Current recorded physical baseline: 0/10,10/10,5/10. Windows3.10 and Ubuntu/WSL3.12 static load checks passed; no new manipulation run was made for the handoff.

Online handoff: https://wangyh666-ust.github.io/Chess-Player------SOARM-101/control-handoff.html
